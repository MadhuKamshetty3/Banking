package com.BankApp.model;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class AccountStatement {

	private int currentBalance;
	List<Transaction> transactionHistory;

	public AccountStatement() {
		super();
	}

	public AccountStatement(int currentBalance, List<Transaction> transactionHistory) {
		super();
		this.currentBalance = currentBalance;
		this.transactionHistory = transactionHistory;
	}

	public int getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(int currentBalance) {
		this.currentBalance = currentBalance;
	}

	public List<Transaction> getTransactionHistory() {
		return transactionHistory;
	}

	public void setTransactionHistory(List<Transaction> transactionHistory) {
		this.transactionHistory = transactionHistory;
	}

	@Override
	public String toString() {
		return "AccountStatement [currentBalance=" + currentBalance + ", transactionHistory=" + transactionHistory
				+ "]";
	}

}
