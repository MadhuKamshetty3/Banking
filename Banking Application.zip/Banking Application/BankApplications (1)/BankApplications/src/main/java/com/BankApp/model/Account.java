package com.BankApp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

@Entity
@Component
public class Account {

	public Account() {
		super();
	}

	public Account(int accountId,
			@NotBlank(message = "Account number required") @Size(min = 10, max = 10, message = "Account Id must contain only 10 digits") String accountNumber,
			String taxId, String accountType, String accountStatus, String dob,
			@NotNull @Size(min = 10, max = 10) @Pattern(regexp = "(0|91)?[6-9][0-9]{9}", message = "Enter valid mobile number") String phoneNo,
			@NotNull @Email(message = "Enter valid email Id") String email,
			@NotNull @Min(value = 1, message = "Enter valid Account Balance") int currentBalance,
			@NotNull @Min(value = 1000, message = "Enter a value greater than $1000") int mab) {
		super();
		this.accountId = accountId;
		this.accountNumber = accountNumber;
		this.taxId = taxId;
		this.accountType = accountType;
		this.accountStatus = accountStatus;
		Dob = dob;
		this.phoneNo = phoneNo;
		this.email = email;
		this.currentBalance = currentBalance;
		this.mab = mab;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int accountId;
	
	@Column(unique=true)
	@NotBlank(message="Account number required")
	@Size(min=10,max=10, message="Account Number must contain only 10 digits")
	private String accountNumber;
	
	private String taxId;
	
	private String accountType;
	
	private String accountStatus;
	
	//@Column(name="Date of Birth")
	@JsonFormat(pattern="MM-dd-yyyy",shape=Shape.STRING)
	private String Dob;
	
	@NotNull
	//@Column(name="Phone number")
	@Size(min=10,max=10)
	@Pattern(regexp="(0|91)?[6-9][0-9]{9}", message="Enter valid mobile number")
	private String phoneNo;
	
	@NotNull
	@Email(message="Enter valid email Id")
	private String email;

	
	@NotNull
	@Column(name="currentBalance")
	@Min(value=1,message="Enter valid Account Balance")
	private int currentBalance;
	
	@NotNull
	//@Column(name="MonthlyAverageBalance")
	@Min(value=1000,message="Enter a value greater than $1000")
	private int mab;

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getTaxId() {
		return taxId;
	}

	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public String getDob() {
		return Dob;
	}

	public void setDob(String dob) {
		Dob = dob;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(int currentBalance) {
		this.currentBalance = currentBalance;
	}

	public int getMab() {
		return mab;
	}

	public void setMab(int mab) {
		this.mab = mab;
	}

	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountNumber=" + accountNumber + ", taxId=" + taxId
				+ ", accountType=" + accountType + ", accountStatus=" + accountStatus + ", Dob=" + Dob + ", phoneNo="
				+ phoneNo + ", email=" + email + ", currentBalance=" + currentBalance + ", mab=" + mab + "]";
	}
	
	}