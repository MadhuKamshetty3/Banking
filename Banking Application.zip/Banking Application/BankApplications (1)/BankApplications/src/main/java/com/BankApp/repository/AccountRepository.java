package com.BankApp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.BankApp.controller.TransferBalanceRequest;
import com.BankApp.model.Account;
import com.BankApp.model.Transaction;

@Component
@Repository
//@RepositoryRestResource(path = "account", collectionResourceRel = "account")
public interface AccountRepository extends JpaRepository<Account,Long> {

	Account findByAccountNumberEquals(String fromAccountNumber);
    //Transaction sendMoney(TransferBalanceRequest transferBalanceRequest);
    //List<Account> getAccountsForIm();
}
