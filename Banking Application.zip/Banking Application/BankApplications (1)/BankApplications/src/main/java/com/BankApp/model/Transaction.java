package com.BankApp.model;


import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Transaction {
	
	public Transaction() {
		super();
	}

	public Transaction( String accountNumber, int transactionAmount, Timestamp transactionDateTime,
			String transactionType,String Message) {
		super();
		//this.transactionId = transactionId;
		this.accountNumber = accountNumber;
		this.transactionAmount = transactionAmount;
		this.transactionDateTime = transactionDateTime;
		this.transactionType = transactionType;
		this.Message=Message;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int transactionId;

	private String accountNumber;

	private int transactionAmount;

	private Timestamp transactionDateTime;
	
	private String transactionType;
	
	private String Message;

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(int transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public Timestamp getTransactionDateTime() {
		return transactionDateTime;
	}

	public void setTransactionDateTime(Timestamp transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", accountNumber=" + accountNumber
				+ ", transactionAmount=" + transactionAmount + ", transactionDateTime=" + transactionDateTime
				+ ", transactionType=" + transactionType + ", Message=" + Message + "]";
	}

	
	

}