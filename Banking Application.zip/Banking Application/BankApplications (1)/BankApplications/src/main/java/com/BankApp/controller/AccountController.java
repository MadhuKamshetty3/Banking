package com.BankApp.controller;

import java.util.ArrayList;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.BankApp.model.Account;
import com.BankApp.model.AccountStatement;
import com.BankApp.model.Transaction;
import com.BankApp.service.AccountServiceImpl;


@RestController
@RequestMapping("/account")
public class AccountController {
	
	Logger logger = LoggerFactory.getLogger(AccountController.class);

	@Autowired
	private AccountServiceImpl accountService;

	@PostMapping("/create")
	public Account createAccount(@RequestBody @Valid Account account) {
		logger.info("In controller class and method createAccount()");
		accountService.save(account);
		return account;
	}

	@GetMapping("/findAll")
	public List<Account> getAccounts() {
		logger.info(" In controller class and method getAccounts()");
		return accountService.findAll();
	}

	@GetMapping("/get/{accountNumber}")
	public Account getAccountById(@PathVariable String accountNumber) {
		logger.info("In controller class and method getAccountById()");
		return accountService.findByAccountNumberEquals(accountNumber);

	}

	@PostMapping("/sendMoney")
	public Transaction sendMoney(@RequestBody @Valid TransferBalanceRequest transferBalanceRequest) {
		logger.info("In controller class and method sendMoney()");
		return accountService.sendMoney(transferBalanceRequest);
	}

	@GetMapping("/accountStatement")
	public AccountStatement getAccountStatement(@RequestBody AccountStatementRequest accountStatementRequest) {
		logger.info(" In controller class and method getAccountStatement() ");
		return accountService.getStatement(accountStatementRequest.getAccountNumber());
	}

	@GetMapping("/investmentManager")
	public List<Account> getAccountsForIm() {
		logger.info(" In controller class and method getAccountsForIm()");
		return accountService.getAccountsForIm();
	}
	
	@GetMapping("/checkMab/{accountNumber}")
	public int monthlyAverageBalanceCheck(@PathVariable String accountNumber) {
		logger.info("In controller class and method monthlyAverageBalanceCheck()");
		return accountService.getMab(accountNumber);
	}
	
}
