package com.BankApp.service;


import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.BankApp.controller.TransferBalanceRequest;
import com.BankApp.model.Account;
import com.BankApp.model.AccountStatement;
import com.BankApp.model.Transaction;
import com.BankApp.repository.AccountRepository;
import com.BankApp.repository.TransactionRepository;

@Service

public class AccountServiceImpl implements AccountService{
	
	Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);
	
	@Autowired
	private AccountRepository accountRepository;
	
	@Autowired
	private TransactionRepository transactionRepository;
	
    
	public List<Account> findAll() {
		logger.info(" In service class and method findAll()");
		return accountRepository.findAll();
	}
   
	public Account save(Account account) {
		//System.out.println(accountRepository);
		logger.info("In service class and method save()");
		return accountRepository.save(account);
		
	}
	
	
	public Account findByAccountNumberEquals(String fromAccountNumber) {
		
		
		List<Account> allAccounts=new ArrayList<Account>();
		allAccounts=accountRepository.findAll();
		List<String> accNum=new ArrayList<String>();
		for(Account account:allAccounts){
			accNum.add(account.getAccountNumber());
		}
		
		if(accNum.contains(fromAccountNumber)){
		Account account= accountRepository.findByAccountNumberEquals(fromAccountNumber);
		logger.info(" In service class and method findByAccountNumberEquals() ");
		return account;
		}
		else{
			throw new NoSuchElementException();
		}
		
	}
	

	public Transaction sendMoney(TransferBalanceRequest transferBalanceRequest) {
		
		logger.info(" In service class and method sendMoney() ");
		 String fromAccountNumber = transferBalanceRequest.getFromAccountNumber();
	        String toAccountNumber = transferBalanceRequest.getToAccountNumber();
	        int amount = transferBalanceRequest.getAmount();
	        if(amount>0){
	        Account fromAccount = accountRepository.findByAccountNumberEquals(fromAccountNumber);
	        Account toAccount = accountRepository.findByAccountNumberEquals(toAccountNumber);
	        if(fromAccount.getCurrentBalance()>amount){
	            fromAccount.setCurrentBalance(fromAccount.getCurrentBalance()- amount);
	            accountRepository.save(fromAccount);
	            toAccount.setCurrentBalance(toAccount.getCurrentBalance() + amount);
	            accountRepository.save(toAccount);
	            Transaction transaction = transactionRepository.save(new Transaction(fromAccountNumber,amount,new Timestamp(System.currentTimeMillis()),"debited","successful"));
	            Transaction newtransaction = transactionRepository.save(new Transaction(toAccountNumber,amount,new Timestamp(System.currentTimeMillis()),"credited","successful"));
	          
	            return transaction;
	        }
	        
	        else{
	        	Transaction transaction=new Transaction();
	        	transaction.setAccountNumber(transferBalanceRequest.getFromAccountNumber());
	        	transaction.setTransactionAmount(transferBalanceRequest.getAmount());
	        	transaction.setTransactionDateTime(new Timestamp(System.currentTimeMillis()));
	        	transaction.setTransactionType("failed Transaction");
	        	transaction.setMessage("Insufficient Balance");
	        	transactionRepository.save(transaction);
	        	  
	        return transaction;
	        }
	        }
	        else{
	        	Transaction transaction=new Transaction();
	        	transaction.setAccountNumber(transferBalanceRequest.getFromAccountNumber());
	        	transaction.setTransactionAmount(transferBalanceRequest.getAmount());
	        	transaction.setTransactionDateTime(new Timestamp(System.currentTimeMillis()));
	        	transaction.setTransactionType("failed Transaction");
	        	transaction.setMessage("Enter a Valid amount");
	        	transactionRepository.save(transaction);
	        	  
	        return transaction;
	        }
	
	}
	
	public AccountStatement getStatement(String accountNumber){
		
		logger.info("In service class and method getStatement()");
		List<Account> allAccounts=new ArrayList<Account>();
		allAccounts=accountRepository.findAll();
		List<String> accNum=new ArrayList<String>();
		for(Account account:allAccounts){
			accNum.add(account.getAccountNumber());
		}
		
		if(accNum.contains(accountNumber)){
		 Account account = accountRepository.findByAccountNumberEquals(accountNumber);
		
	        return new AccountStatement(account.getCurrentBalance(),transactionRepository.findByAccountNumberEquals(accountNumber));
		}
		else{
			throw new NoSuchElementException();
		}
	}

	public List<Account> getAccountsForIm() {
		logger.info("In service class and method getAccountsForIm()");
		List<Account> accountsBefore = accountRepository.findAll();
		//System.out.println(accountsBefore);
		List<Account> accountsAfter=new ArrayList<Account>();
		for(Account a :accountsBefore){
	    	if((a.getPhoneNo()!=null)&&(a.getMab()>1000)&&(a.getCurrentBalance()>0)&&
	    			(a.getAccountStatus().equalsIgnoreCase("active"))){
	    		accountsAfter.add(a);
	    	}
	    }
		return accountsAfter;
	}

	@Override
	public int getMab(String accountNumber) {
		logger.info("In service class and method getMab() ");
		List<Account> allAccounts=new ArrayList<Account>();
		allAccounts=accountRepository.findAll();
		List<String> accNum=new ArrayList<String>();
		for(Account account:allAccounts){
			accNum.add(account.getAccountNumber());
		}
		
		if(accNum.contains(accountNumber)){
			return (accountRepository.findByAccountNumberEquals(accountNumber)).getMab();
		}
		else{
			throw new NoSuchElementException();
		}
		
	}
	


}
