package com.BankApp.controller;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

@Entity
@Component
public class TransferBalanceRequest {

	private String fromAccountNumber;

	private String toAccountNumber;

	@NotNull(message="Enter the amount to be debited")
	private int amount;

	public TransferBalanceRequest() {
		super();
	}


	public TransferBalanceRequest(String fromAccountNumber, String toAccountNumber,
			@NotNull(message = "Enter the amount to be debited") int amount) {
		super();
		this.fromAccountNumber = fromAccountNumber;
		this.toAccountNumber = toAccountNumber;
		this.amount = amount;
	}



	public String getFromAccountNumber() {
		return fromAccountNumber;
	}

	public void setFromAccountNumber(String fromAccountNumber) {
		this.fromAccountNumber = fromAccountNumber;
	}

	public String getToAccountNumber() {
		return toAccountNumber;
	}

	public void setToAccountNumber(String toAccountNumber) {
		this.toAccountNumber = toAccountNumber;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	
}
