package com.BankApp.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.BankApp.controller.TransferBalanceRequest;
import com.BankApp.model.Account;
import com.BankApp.model.AccountStatement;
import com.BankApp.model.Transaction;

@Component
public interface AccountService {

	public List<Account> findAll();
	public Account save(Account account);
	public Account findByAccountNumberEquals(String fromAccountNumber) ;
	public Transaction sendMoney(TransferBalanceRequest transferBalanceRequest);
	public AccountStatement getStatement(String accountNumber);
	public List<Account> getAccountsForIm();
	public int getMab(String accountNumber);
}
