package com.BankApp.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.assertj.core.util.Arrays;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.BankApp.model.Account;
import com.BankApp.model.AccountStatement;
import com.BankApp.model.Transaction;
import com.BankApp.service.AccountServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.sun.xml.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

@RunWith(SpringJUnit4ClassRunner.class)
@WebMvcTest(AccountController.class)
public class AccountControllerTest {

	@Autowired
	MockMvc mockMvc;

	@InjectMocks
	AccountController accountController;

	@MockBean
	AccountServiceImpl accountService;

	ObjectMapper om = new ObjectMapper();

	@Test
	public void testCreateAccount() throws Exception {

		Account mockAccount = new Account(1, "1234567890", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1000, 1200);
		Account newMockAccount = new Account(1, "1234567891", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1200, 1200);

		List<Account> mockList = new ArrayList<Account>();
		mockList.add(mockAccount);
		mockList.add(newMockAccount);

		String jsonRequest = om.writeValueAsString(mockAccount);
		String URI = "/account/create";
		Mockito.when(accountService.save(Mockito.any(Account.class))).thenReturn(mockAccount);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(URI).accept(MediaType.APPLICATION_JSON)
				.content(jsonRequest).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
		MockHttpServletResponse response = result.getResponse();

		String outputInJson = response.getContentAsString();

		assertEquals(outputInJson, jsonRequest);

	}
	
	@Test
	public void testGetAllAccounts() throws Exception{
		
		Account mockAccount = new Account(1, "1234567890", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1000, 1200);
		Account newMockAccount = new Account(1, "1234567891", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1200, 1200);

		List<Account> mockList = new ArrayList<Account>();
		mockList.add(mockAccount);
		mockList.add(newMockAccount);
		
		String jsonRequest = om.writeValueAsString(mockList);
		String URI = "/account/findAll";
		Mockito.when(accountService.findAll()).thenReturn(mockList);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(URI);
		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
		MockHttpServletResponse response = result.getResponse();

		String outputInJson = response.getContentAsString();

		assertEquals(outputInJson, jsonRequest);

	}
	
	@Test
	public void testGetAccountById() throws Exception{
		Account mockAccount = new Account(1, "1234567890", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1000, 1200);
		

		String jsonRequest = om.writeValueAsString(mockAccount);
		String URI = "/account/get/1234567890";
		Mockito.when(accountService.findByAccountNumberEquals("1234567890")).thenReturn(mockAccount);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(URI);
		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
		MockHttpServletResponse response = result.getResponse();

		String outputInJson = response.getContentAsString();
		
		System.out.println(outputInJson);

		assertEquals(outputInJson, jsonRequest);
	}
	
	@Test
	public void testSendMoney() throws Exception{
		Account mockAccount = new Account(1, "1234567890", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1000, 1200);
		Account newMockAccount = new Account(1, "1234567891", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1200, 1200);
		
		TransferBalanceRequest transferBalanceRequest=new TransferBalanceRequest("1234567890","1234567891",500);
		Transaction transaction = new Transaction(mockAccount.getAccountNumber(),500,
				new Timestamp(System.currentTimeMillis()),"debited","successful");
		
		String jsonRequest = om.writeValueAsString(transferBalanceRequest);
		String URI = "/account/sendMoney";
		Mockito.when(accountService.findByAccountNumberEquals("1234567890")).thenReturn(mockAccount);
		Mockito.when(accountService.findByAccountNumberEquals("1234567891")).thenReturn(newMockAccount);
		Mockito.when(accountService.sendMoney(transferBalanceRequest)).thenReturn(transaction);
		
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(URI).accept(MediaType.APPLICATION_JSON)
				.content(jsonRequest).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
		MockHttpServletResponse response = result.getResponse();

		String outputInJson = response.getContentAsString();

		
	}
	@Test 
	public void testAccountStatement() throws Exception{
		Account mockAccount = new Account(1, "1234567890", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1000, 1200);
		Account newMockAccount = new Account(1, "1234567891", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1200, 1200);

		TransferBalanceRequest transferBalanceRequest=new TransferBalanceRequest("1234567890","1234567891",500);
		TransferBalanceRequest transferBalanceRequest1=new TransferBalanceRequest("1234567890","1234567891",200);
		
		Transaction transaction1=new Transaction(mockAccount.getAccountNumber(),500,
				new Timestamp(System.currentTimeMillis()),"debited","successful");
		Transaction transaction2=new Transaction(mockAccount.getAccountNumber(),200,
				new Timestamp(System.currentTimeMillis()),"debited","successful");
		
		List<Transaction> transactionList=new ArrayList<Transaction>();
		transactionList.add(transaction1);
		transactionList.add(transaction2);
		
		AccountStatement accountStatement=new AccountStatement(300,transactionList);
		AccountStatementRequest accountStatementRequest=new AccountStatementRequest("1234567890");
		
		Mockito.when(accountService.getStatement("1234567890")).thenReturn(accountStatement);
		
		String jsonRequest = om.writeValueAsString(accountStatementRequest);
		String URI = "/account/accountStatement";
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(URI).accept(MediaType.APPLICATION_JSON)
				.content(jsonRequest).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
		MockHttpServletResponse response = result.getResponse();
		
		String outputInJson = response.getContentAsString();
		
		Gson gson = new Gson();
        AccountStatement accountStatement1 = gson.fromJson(outputInJson, AccountStatement.class);
        
        assertEquals(300,accountStatement1.getCurrentBalance());
        assertEquals(2,accountStatement1.getTransactionHistory().size());
		
	}

	@Test
	public void testGetAccountsForIm() throws Exception{

	Account mockAccount = new Account(1, "1234567890", "abc", "savings", "active", "22-04-2022", "9876543210",
	"yesh@gmail.com", 1000, 1200);
	Account newMockAccount = new Account(1, "1234567891", "abc", "savings", "not active", "22-04-2022", "9876543210",
	"yesh@gmail.com", 1200, 1200);

	List<Account> mockList = new ArrayList<Account>();
	mockList.add(mockAccount);
	mockList.add(newMockAccount);

	String jsonRequest = om.writeValueAsString(mockList);
	String URI = "/account/investmentManager";
	Mockito.when(accountService.getAccountsForIm()).thenReturn(mockList);

	RequestBuilder requestBuilder = MockMvcRequestBuilders.get(URI);
	MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
	MockHttpServletResponse response = result.getResponse();

	String outputInJson = response.getContentAsString();

	assertEquals(outputInJson, jsonRequest);
	}
	
	@Test
	public void testGetMab() throws Exception{
		Account mockAccount = new Account(1, "1234567890", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1000, 1200);
		String URI = "/account/checkMab/1234567890";
		Mockito.when(accountService.getMab("1234567890")).thenReturn(1200);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(URI);
		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
		MockHttpServletResponse response = result.getResponse();
 
		String outputInJson = response.getContentAsString();
		
		assertEquals(1200,Integer.parseInt(outputInJson));
	}
	
	
}
