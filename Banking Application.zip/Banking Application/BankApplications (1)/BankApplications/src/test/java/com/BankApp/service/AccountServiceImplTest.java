package com.BankApp.service;

import static org.junit.Assert.*;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.BankApp.controller.AccountStatementRequest;
import com.BankApp.controller.TransferBalanceRequest;
import com.BankApp.model.Account;
import com.BankApp.model.AccountStatement;
import com.BankApp.model.Transaction;
import com.BankApp.repository.AccountRepository;
import com.BankApp.repository.TransactionRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AccountServiceImplTest {
	
	@Autowired
	AccountServiceImpl accountService;
	
	@MockBean
	AccountRepository accountRepository;
	
	@MockBean
	TransactionRepository transactionRepository;
	
    @Autowired
    AccountService accService;

	@Test
	public void testSave() {
		
		Account mockAccount = new Account(1, "1234567890", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1000, 1200);
		
		Mockito.when(accountRepository.save(mockAccount)).thenReturn(mockAccount);
		
		Account outPut=accountService.save(mockAccount);
		assertEquals(outPut,mockAccount);
		
		//assertThat(accountService.save(mockAccount)).isEqualTo(mockAccount);
		
		
	}
	
	@Test
	public void testFindAll(){
		Account mockAccount = new Account(1, "1234567890", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1000, 1200);
		Account newMockAccount = new Account(1, "1234567891", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1200, 1200);

		List<Account> mockList = new ArrayList<Account>();
		mockList.add(mockAccount);
		mockList.add(newMockAccount);
		
	    Mockito.when(accountRepository.findAll()).thenReturn(mockList);
	    
	   List<Account> output=accountService.findAll();
	   assertEquals(2,output.size());
	  
	    
	}
	
	@Test
	public void testFindByAccountNumberEquals(){
		Account mockAccount = new Account(1, "1234567890", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1000, 1200);
		Account newMockAccount = new Account(1, "1234567891", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1200, 1200);

		List<Account> mockList = new ArrayList<Account>();
		mockList.add(mockAccount);
		mockList.add(newMockAccount);
		
	    Mockito.when(accountRepository.findAll()).thenReturn(mockList);
	    Mockito.when(accountRepository.findByAccountNumberEquals("1234567890")).thenReturn(mockAccount);
	   
	    Account output=accountService.findByAccountNumberEquals("1234567890");
	   // System.out.println("in testFindByAccountNumberEquals"+output.toString());
	    assertEquals(mockAccount,output);
	  
	    
	}
	
	@Test
	public void testSendMoney(){
		Account mockAccount = new Account(1, "1234567890", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1000, 1200);
		Account newMockAccount = new Account(1, "1234567891", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1200, 1200);

		List<Account> mockList = new ArrayList<Account>();
		mockList.add(mockAccount);
		mockList.add(newMockAccount);
		
	    Mockito.when(accountRepository.findAll()).thenReturn(mockList);

		
		/*System.out.println("----------------------------------");
		System.out.println("in send money"+accService);*/

		TransferBalanceRequest transferBalanceRequest=new TransferBalanceRequest("1234567890","1234567891",500);
		Transaction transaction = new Transaction(mockAccount.getAccountNumber(),500,
				new Timestamp(System.currentTimeMillis()),"debited","successful");
		Mockito.when(accountRepository.findByAccountNumberEquals("1234567890")).thenReturn(mockAccount);
		Mockito.when(accountRepository.findByAccountNumberEquals("1234567891")).thenReturn(newMockAccount);
		Mockito.when(accService.sendMoney(transferBalanceRequest)).thenReturn(transaction);

		
		
		Transaction output=accountService.sendMoney(transferBalanceRequest);
		
		assertEquals(500,accountService.findByAccountNumberEquals("1234567890").getCurrentBalance());
		
		
	}
	
	@Test
	public void testAccontStatement(){
		
		Account mockAccount = new Account(1, "1234567890", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1000, 1200);
		Account newMockAccount = new Account(1, "1234567891", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1200, 1200);

		List<Account> mockList = new ArrayList<Account>();
		mockList.add(mockAccount);
		mockList.add(newMockAccount);
		
	    Mockito.when(accountRepository.findAll()).thenReturn(mockList);

		AccountStatementRequest accountStatementRequest=new AccountStatementRequest("1234567890");
		Mockito.when(accountRepository.findByAccountNumberEquals("1234567890")).thenReturn(mockAccount);
		
		TransferBalanceRequest transferBalanceRequest=new TransferBalanceRequest("1234567890","1234567891",500);
		TransferBalanceRequest transferBalanceRequest1=new TransferBalanceRequest("1234567890","1234567891",200);
		
		Transaction transaction1=new Transaction(mockAccount.getAccountNumber(),500,
				new Timestamp(System.currentTimeMillis()),"debited","successful");
		Transaction transaction2=new Transaction(mockAccount.getAccountNumber(),200,
				new Timestamp(System.currentTimeMillis()),"debited","successful");
		
		List<Transaction> transactionList=new ArrayList<Transaction>();
		transactionList.add(transaction1);
		transactionList.add(transaction2);
		
		Mockito.when(accountRepository.findByAccountNumberEquals("1234567890")).thenReturn(mockAccount);
		Mockito.when(accountRepository.findByAccountNumberEquals("1234567891")).thenReturn(newMockAccount);		
		Mockito.when(accService.sendMoney(transferBalanceRequest)).thenReturn(transaction1);
		Mockito.when(accService.sendMoney(transferBalanceRequest1)).thenReturn(transaction2);
		//System.out.println(mockAccount.getCurrentBalance());
		
        /*accountService.sendMoney(transferBalanceRequest);       
        accountService.sendMoney(transferBalanceRequest1);*/
        
	   Mockito.when(transactionRepository.findByAccountNumberEquals("1234567890")).thenReturn(transactionList);
	   
	   AccountStatement accountStatement= accountService.getStatement("1234567890");
	   
	  /* System.out.println(accountStatement.getTransactionHistory());
	   
	   System.out.println(accountStatement.toString());*/
	   assertEquals(2,accountStatement.getTransactionHistory().size());
	   assertEquals(300,accountStatement.getCurrentBalance());

	}
	
	@Test
	public void testGetAccountsForIm(){
		
		Account mockAccount = new Account(1, "1234567890", "abc", "savings", "active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1000, 1200);
		Account newMockAccount = new Account(1, "1234567891", "abc", "savings", "not active", "22-04-2022", "9876543210",
				"yesh@gmail.com", 1200, 1200);
		
		List<Account> expected=new ArrayList<Account>();
		expected.add(mockAccount);
		
		Mockito.when(accService.getAccountsForIm()).thenReturn(expected);
		
		List<Account> output=accountService.getAccountsForIm();
		assertEquals(expected,output);
	}
	

}
