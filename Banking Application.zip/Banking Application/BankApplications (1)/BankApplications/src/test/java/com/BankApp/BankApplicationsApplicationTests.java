package com.BankApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankApplicationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
